chrome.runtime.onInstalled.addListener(() => {
    console.log("Page Translator Extension Installed.")
});