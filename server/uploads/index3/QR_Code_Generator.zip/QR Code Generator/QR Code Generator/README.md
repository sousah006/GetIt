# Day #4

### QR Code Generator
In this tutorial ([Open in Youtube](https://youtu.be/I50Xwve6QW4)),  I am gonna showing to you how to build a QR Code Generator with javascript. this qr code generator also are responsive and have download and share button❗️

# Screenshot
Here we have project screenshot :

![screenshot](screenshot.jpg)
